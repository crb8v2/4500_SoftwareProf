#ifdef TARGET_EMSCRIPTEN
#include <emscripten/emscripten.h>
#endif