#include <stdio.h>
#include <emscripten/emscripten.h>


int main() {
    char *thing = emscripten_run_script_string("document.getElementById('codespace').value");
   printf("HI!"); 
    char hold;
    int adder = 0;
    while (hold != '\0'){
        hold = thing[adder];
        printf("%c", hold);
        adder++;
    }
  return 0;
}
