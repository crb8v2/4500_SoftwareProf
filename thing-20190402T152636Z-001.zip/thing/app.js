


var frame = document.getElementById('result'); //changes the styling of the canvas text;
    frame.onload = function () {
        var body = frame.contentWindow.document.querySelector('body');
        body.style.color = 'lime';
    };

function saver(){
  alert("something happened!");

}






